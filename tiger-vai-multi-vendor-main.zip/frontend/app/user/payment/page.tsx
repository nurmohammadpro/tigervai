import ComingSoonPage from "@/components/ui/custom/common/Comming-Soon";
import React from "react";

const page = () => {
  return <ComingSoonPage />;
};

export default page;
