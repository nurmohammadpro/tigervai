"use client";
import { useScrollRestorer } from "next-scroll-restorer";
const ClientSideScrollRestorer = () => {
  useScrollRestorer();
  return <></>;
};
export default ClientSideScrollRestorer;
