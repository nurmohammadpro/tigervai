export class Meilisearch {}
