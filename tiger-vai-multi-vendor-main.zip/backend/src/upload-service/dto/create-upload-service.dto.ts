export class CreateUploadServiceDto {}
