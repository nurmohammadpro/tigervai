here product status is global
here review status is also global
so any kind of cross db population should be getting from global db globalProducts
we do it for future like in future if we do like short by rating or short by sell then this will come first ok,
