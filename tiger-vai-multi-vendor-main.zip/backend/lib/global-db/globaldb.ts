export const globalUser = 'tiger-vai-user'
export const globalSells = 'tiger-vai-sells'
export const globalProducts = 'tiger-vai-products'

export const globalOther = 'tiger-vai-other'

export const globalCart = 'tiger-vai-cart'